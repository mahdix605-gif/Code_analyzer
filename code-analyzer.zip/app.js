// المنت‌ها
const languageSelect = document.getElementById('language');
const codeInput = document.getElementById('codeInput');
const charCount = document.getElementById('charCount');
const analyzeBtn = document.getElementById('analyzeBtn');
const loading = document.getElementById('loading');
const results = document.getElementById('results');
const resultsContent = document.getElementById('resultsContent');
const copyResults = document.getElementById('copyResults');
const newAnalysis = document.getElementById('newAnalysis');

// چک‌باکس‌ها
const bugCheck = document.getElementById('bugCheck');
const securityCheck = document.getElementById('securityCheck');
const performanceCheck = document.getElementById('performanceCheck');
const styleCheck = document.getElementById('styleCheck');

// شمارش کاراکترها
codeInput.addEventListener('input', () => {
    charCount.textContent = codeInput.value.length;
});

// دکمه تحلیل
analyzeBtn.addEventListener('click', analyzeCode);

// تحلیل کد
async function analyzeCode() {
    const code = codeInput.value.trim();
    const language = languageSelect.value;
    
    // اعتبارسنجی
    if (!code) {
        alert('❌ لطفاً کد خود را وارد کنید!');
        return;
    }
    
    // نمایش لودینگ
    loading.classList.add('show');
    results.classList.remove('show');
    analyzeBtn.disabled = true;
    
    // شبیه‌سازی تحلیل (2 ثانیه)
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // تولید نتایج
    const analysisResults = generateAnalysis(code, language);
    
    // نمایش نتایج
    displayResults(analysisResults);
    
    // مخفی کردن لودینگ
    loading.classList.remove('show');
    results.classList.add('show');
    analyzeBtn.disabled = false;
}

// تولید تحلیل
function generateAnalysis(code, language) {
    const results = [];
    
    // بررسی باگ
    if (bugCheck.checked) {
        results.push({
            type: 'bug',
            title: '🐛 باگ احتمالی یافت شد',
            description: `در کد ${getLanguageName(language)} شما، متغیرهایی که تعریف نشده‌اند استفاده شده است. این می‌تواند باعث خطای Runtime شود.`
        });
        
        if (code.includes('while') || code.includes('for')) {
            results.push({
                type: 'bug',
                title: '⚠️ احتمال حلقه بی‌نهایت',
                description: 'حلقه‌های شما شرط خروج مشخصی ندارند. لطفاً شرط توقف را بررسی کنید.'
            });
        }
    }
    
    // بررسی امنیت
    if (securityCheck.checked) {
        results.push({
            type: 'security',
            title: '🔒 مشکل امنیتی',
            description: 'ورودی کاربر بدون اعتبارسنجی استفاده شده است. این می‌تواند منجر به حملات SQL Injection یا XSS شود.'
        });
        
        if (code.includes('password') || code.includes('token')) {
            results.push({
                type: 'security',
                title: '🚨 اطلاعات حساس در کد',
                description: 'اطلاعات حساس (رمز عبور، توکن) نباید به صورت Hardcode در کد باشد. از متغیرهای محیطی استفاده کنید.'
            });
        }
    }
    
    // بررسی عملکرد
    if (performanceCheck.checked) {
        results.push({
            type: 'performance',
            title: '⚡ بهینه‌سازی عملکرد',
            description: 'استفاده از حلقه‌های تو در تو می‌تواند عملکرد را کاهش دهد. پیشنهاد: از الگوریتم‌های بهینه‌تر استفاده کنید.'
        });
        
        if (code.length > 500) {
            results.push({
                type: 'performance',
                title: '📊 کد طولانی',
                description: 'تابع شما بیش از حد طولانی است. پیشنهاد: کد را به توابع کوچک‌تر تقسیم کنید.'
            });
        }
    }
    
    // بررسی استایل
    if (styleCheck.checked) {
        results.push({
            type: 'style',
            title: '🎨 بهبود خوانایی کد',
            description: 'نام‌گذاری متغیرها واضح نیست. از نام‌های توصیفی استفاده کنید (مثلاً: userAge به جای x).'
        });
    }
    
    // اگه هیچ مشکلی نبود
    if (results.length === 0) {
        results.push({
            type: 'performance',
            title: '✅ کد شما عالی است!',
            description: 'هیچ مشکل جدی در کد شما یافت نشد. کد تمیز و بهینه است!'
        });
    }
    
    return results;
}

// نمایش نتایج
function displayResults(analysisResults) {
    resultsContent.innerHTML = '';
    
    analysisResults.forEach(result => {
        const resultDiv = document.createElement('div');
        resultDiv.className = 'result-item';
        resultDiv.innerHTML = `
            <span class="result-type ${result.type}">${result.type.toUpperCase()}</span>
            <div class="result-title">${result.title}</div>
            <div class="result-desc">${result.description}</div>
        `;
        resultsContent.appendChild(resultDiv);
    });
}

// نام زبان
function getLanguageName(lang) {
    const names = {
        python: 'Python',
        javascript: 'JavaScript',
        php: 'PHP',
        csharp: 'C#',
        cpp: 'C++',
        sql: 'SQL'
    };
    return names[lang] || lang;
}

// کپی نتایج
copyResults.addEventListener('click', () => {
    const text = resultsContent.innerText;
    navigator.clipboard.writeText(text).then(() => {
        const originalText = copyResults.textContent;
        copyResults.textContent = '✅ کپی شد!';
        setTimeout(() => {
            copyResults.textContent = originalText;
        }, 2000);
    });
});

// تحلیل جدید
newAnalysis.addEventListener('click', () => {
    codeInput.value = '';
    charCount.textContent = '0';
    results.classList.remove('show');
    codeInput.focus();
});

// نمونه کد
const exampleCodes = {
    python: `def calculate_sum(numbers):
    total = 0
    for num in numbers:
        total += num
    return total

result = calculate_sum([1, 2, 3, 4, 5])
print(result)`,
    
    javascript: `function calculateSum(numbers) {
    let total = 0;
    for (let num of numbers) {
        total += num;
    }
    return total;
}

const result = calculateSum([1, 2, 3, 4, 5]);
console.log(result);`
};

// زبان تغییر کرد
languageSelect.addEventListener('change', () => {
    const lang = languageSelect.value;
    if (exampleCodes[lang] && !codeInput.value) {
        codeInput.placeholder = exampleCodes[lang];
    }
});